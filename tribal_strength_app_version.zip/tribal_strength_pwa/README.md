# Tribal Strength PWA

This is an installable Progressive Web App (PWA) version of the workout tracker.

## To use on iPhone
1. Host these files at an HTTPS address (for example, a GitHub Pages site).
2. Open the hosted address in Safari.
3. Tap Share → Add to Home Screen.
4. Launch it from the new Home Screen icon.

The app saves data in the browser on the device. Use Export backup occasionally. If browser storage is cleared, local data may be lost.

This is a web app, not an App Store native app. The plan is general fitness guidance; adjust loads to your ability, use good technique, and allow recovery.
